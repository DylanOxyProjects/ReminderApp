package com.example.dylan.reminderapp;

// if a new reminder is added, I will start this activity only long enough to add it
// to the arrayList but than I will go back to the main menu before any content is shown



import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class ViewRemindersActivity extends AppCompatActivity{

    public ArrayList<ReminderObject> reminderList = new ArrayList<>();
    public Button mainMenuButton;
    public Button addMenuButton;
    public Button delete;
    public ListView listView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Deserialization
        String filename = "reminderStorage";
        try{
            // Reading the object from a file
            // FileOutputStream file = new FileOutputStream(new File(getFilesDir(), filename));
            FileInputStream file = new FileInputStream(new File(getFilesDir(), filename));
            ObjectInputStream in = new ObjectInputStream(file);

            // Method for deserialization of object
            reminderList = (ArrayList)in.readObject();
            in.close();
            file.close();

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }


        setContentView(R.layout.reminder_list_view);
        mainMenuButton = findViewById(R.id.mainMenuBTN);
        addMenuButton = findViewById(R.id.addReminderBTN);
        delete = findViewById(R.id.deleteReminders);
        listView = findViewById(R.id.reminderListView);


        ReminderAdapter reminderAdapter = new ReminderAdapter(this, reminderList);
        listView.setAdapter(reminderAdapter);

        mainMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewRemindersActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        addMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentlol = new Intent(ViewRemindersActivity.this, addReminderActivity.class);
                intentlol.putExtra("testKey", 2000000);
                startActivity(intentlol);
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                File dir = getFilesDir();
                File file = new File(dir, "reminderStorage");
                boolean deleted = file.delete();

                Intent intent = new Intent(ViewRemindersActivity.this, ViewRemindersActivity.class);
                startActivity(intent);
            }
        });


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(ViewRemindersActivity.this, EditReminder.class);
                intent.putExtra("position", position);
                startActivity(intent);
            }
        });
    }
}


