package com.example.dylan.reminderapp;

// if a new reminder is added, I will start this activity only long enough to add it
// to the arrayList but than I will go back to the main menu before any content is shown



import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class ViewRemindersActivity extends AppCompatActivity{

    public ArrayList<ReminderObject> reminderList = new ArrayList<>();
    public Button mainMenuButton;
    public Button addMenuButton;
    public Button delete;
    public ListView listView;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        CompactReminderObject storedReminders;

        // Deserialization
        String filename = "reminderStorage";
        try{
            // Reading the object from a file
            // FileOutputStream file = new FileOutputStream(new File(getFilesDir(), filename));
            FileInputStream file = new FileInputStream(new File(getFilesDir(), filename));
            ObjectInputStream in = new ObjectInputStream(file);

            // Method for deserialization of object
            reminderList = (ArrayList)in.readObject();
            in.close();
            file.close();

        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }


        /*
        if (bundle != null && bundle.getInt("addReminderKey") == 57078576){
            StringBuffer reminderStringBuffer = readMethod();
            String reminderString = reminderStringBuffer.toString();
            //List<String> reminderValues = Arrays.asList(reminderString.split("|"));
            String[] reminderArray = reminderString.split(",  ");

            ReminderObject currentReminder = new ReminderObject();
            currentReminder.reminderTitle = reminderArray[0];
            currentReminder.reminderDateTime = reminderArray[1];
            currentReminder.reminderUrgency = reminderArray[2];
            currentReminder.reminderTopic = reminderArray[3];
            reminderList.add(currentReminder);
        }
        */

        setContentView(R.layout.reminder_list_view);
        mainMenuButton = findViewById(R.id.mainMenuBTN);
        addMenuButton = findViewById(R.id.addReminderBTN);
        delete = findViewById(R.id.deleteReminders);
        listView = findViewById(R.id.reminderListView);


        ReminderAdapter reminderAdapter = new ReminderAdapter(this, reminderList);
        listView.setAdapter(reminderAdapter);

        mainMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ViewRemindersActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });

        addMenuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentlol = new Intent(ViewRemindersActivity.this, addReminderActivity.class);
                intentlol.putExtra("testKey", 2000000);
                startActivity(intentlol);
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                File dir = getFilesDir();
                File file = new File(dir, "reminderStorage");
                boolean deleted = file.delete();

                Intent intent = new Intent(ViewRemindersActivity.this, ViewRemindersActivity.class);
                startActivity(intent);


            }
        });

        /*
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ReminderObject currentReminder = reminderList.get(position);
                Intent intent = new Intent(ViewRemindersActivity.this, DetailedReminderActivity.class);
                //prepare title to be passed to ViewList
                intent.putExtra("title", currentReminder.reminderTitle);
                //prepare date/time to be passed to ViewList
                intent.putExtra("dateTime", currentReminder.reminderDateTime);
                //prepare urgency to be passed to ViewList
                intent.putExtra("urgency", currentReminder.reminderUrgency);
                //prepare topic to be passed to ViewList
                intent.putExtra("topic", currentReminder.reminderTopic);
                startActivity(intent);
            }
        });
        */
    }


}



/*
        if (reminderList.size() == 0){
            StringBuffer stringBuffer = readMethod();
            String allReminders = stringBuffer.toString();
            String[] reminderArray = allReminders.split(" EndOfReminder");

            int reminderINDX = 0;
            ReminderObject reminderObject = null;
            for (String aReminderArray : reminderArray) {

                if (reminderINDX == 0) {
                    reminderObject = new ReminderObject();
                }

                reminderObject.reminderTitle = reminderArray[reminderINDX];

                if (reminderINDX == 3) {
                    reminderINDX = 0;
                    reminderList.add(reminderObject);
                } else {
                    reminderINDX++;
                }
            }
        }
        public StringBuffer readMethod(){
        try{
            String message;
            FileInputStream fileInputStream = openFileInput("reminder storage");
            InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
            BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
            StringBuffer stringBuffer = new StringBuffer();

            while ((message=bufferedReader.readLine()) != null){
                stringBuffer.append(message + "\n");
            }
            return stringBuffer;

        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }
*/